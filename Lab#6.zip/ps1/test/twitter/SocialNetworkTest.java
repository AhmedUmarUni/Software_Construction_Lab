package twitter;

import static org.junit.Assert.*;

import java.time.Instant;
import java.util.*;

import org.junit.Test;

public class SocialNetworkTest {

    // Ensure assertions are enabled
    @Test(expected=AssertionError.class)
    public void testAssertionsEnabled() {
        assert false; // make sure assertions are enabled with VM argument: -ea
    }
    
    // Test Cases for guessFollowsGraph()

    @Test
    public void testGuessFollowsGraphEmpty() {
        Map<String, Set<String>> followsGraph = SocialNetwork.guessFollowsGraph(new ArrayList<>());
        assertTrue("expected empty graph", followsGraph.isEmpty());
    }
    
    @Test
    public void testGuessFollowsGraphNoMentions() {
        List<Tweet> tweets = Arrays.asList(
            new Tweet(1, "user1", "This is a tweet without mentions.", Instant.now()),
            new Tweet(2, "user2", "Another tweet here.", Instant.now())
        );
        Map<String, Set<String>> followsGraph = SocialNetwork.guessFollowsGraph(tweets);
        assertTrue("expected empty graph", followsGraph.isEmpty());
    }

    @Test
    public void testGuessFollowsGraphSingleMention() {
        List<Tweet> tweets = Collections.singletonList(
            new Tweet(1, "user1", "Hello @user2!", Instant.now())
        );
        Map<String, Set<String>> followsGraph = SocialNetwork.guessFollowsGraph(tweets);
        
        Set<String> expectedFollowers = new HashSet<>(Collections.singletonList("user2"));
        assertEquals("expected user1 to follow user2", expectedFollowers, followsGraph.get("user1"));
    }

    @Test
    public void testGuessFollowsGraphMultipleMentions() {
        List<Tweet> tweets = Collections.singletonList(
            new Tweet(1, "user1", "Hey @user2 and @user3!", Instant.now())
        );
        Map<String, Set<String>> followsGraph = SocialNetwork.guessFollowsGraph(tweets);
        
        Set<String> expectedFollowers = new HashSet<>(Arrays.asList("user2", "user3"));
        assertEquals("expected user1 to follow user2 and user3", expectedFollowers, followsGraph.get("user1"));
    }

    @Test
    public void testGuessFollowsGraphMultipleTweetsFromOneUser() {
        List<Tweet> tweets = Arrays.asList(
            new Tweet(1, "user1", "Hello @user2!", Instant.now()),
            new Tweet(2, "user1", "Hey @user2! Check this out. @user3", Instant.now())
        );
        Map<String, Set<String>> followsGraph = SocialNetwork.guessFollowsGraph(tweets);
        
        Set<String> expectedFollowers = new HashSet<>(Arrays.asList("user2", "user3"));
        assertEquals("expected user1 to follow user2 and user3", expectedFollowers, followsGraph.get("user1"));
    }

    // Test Cases for influencers()

    @Test
    public void testInfluencersEmpty() {
        Map<String, Set<String>> followsGraph = new HashMap<>();
        List<String> influencers = SocialNetwork.influencers(followsGraph);
        assertTrue("expected empty list", influencers.isEmpty());
    }

    @Test
    public void testInfluencersSingleUserWithoutFollowers() {
        Map<String, Set<String>> followsGraph = new HashMap<>();
        followsGraph.put("user1", new HashSet<>()); // user1 has no followers
        List<String> influencers = SocialNetwork.influencers(followsGraph);
        assertTrue("expected empty influencer list", influencers.isEmpty());
    }

    @Test
    public void testInfluencersSingleInfluencer() {
        Map<String, Set<String>> followsGraph = new HashMap<>();
        followsGraph.put("user1", new HashSet<>(Arrays.asList("user2")));
        followsGraph.put("user2", new HashSet<>());
        
        List<String> influencers = SocialNetwork.influencers(followsGraph);
        assertEquals("expected single influencer", Collections.singletonList("user2"), influencers);
    }

    @Test
    public void testInfluencersMultipleInfluencers() {
        Map<String, Set<String>> followsGraph = new HashMap<>();
        followsGraph.put("user1", new HashSet<>(Arrays.asList("user2")));
        followsGraph.put("user2", new HashSet<>(Arrays.asList("user1", "user3")));
        followsGraph.put("user3", new HashSet<>());
        
        List<String> influencers = SocialNetwork.influencers(followsGraph);
        List<String> expectedOrder = Arrays.asList("user2", "user1", "user3");
        assertEquals("expected correct order of influencers", expectedOrder, influencers);
    }

    @Test
    public void testInfluencersTiedInfluence() {
        Map<String, Set<String>> followsGraph = new HashMap<>();
        followsGraph.put("user1", new HashSet<>(Arrays.asList("user2")));
        followsGraph.put("user2", new HashSet<>(Arrays.asList("user1")));
        followsGraph.put("user3", new HashSet<>(Arrays.asList("user1", "user2"))); // all users are tied
        
        List<String> influencers = SocialNetwork.influencers(followsGraph);
        List<String> expectedOrder = Arrays.asList("user1", "user2", "user3");
        assertEquals("expected correct order of tied influencers", expectedOrder, influencers);
    }
}
