package twitter;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SocialNetwork{

 public static Map<String, Set<String>> guessFollowsGraph(List<Tweet> tweets) {
    Map<String, Set<String>> followsGraph = new HashMap<>();
    Pattern mentionPattern = Pattern.compile("@(\\w+)");
    
    for (Tweet tweet : tweets) {
        String author = tweet.getAuthor().toLowerCase(); // Case-insensitive usernames
        String text = tweet.getText();
        Matcher matcher = mentionPattern.matcher(text);
        
        Set<String> mentionedUsers = followsGraph.getOrDefault(author, new HashSet<>());
        
        // Find all mentioned users
        while (matcher.find()) {
            String mentionedUser = matcher.group(1).toLowerCase();
            
            // Avoid self-mentioning
            if (!mentionedUser.equals(author)) {
                mentionedUsers.add(mentionedUser);
            }
        }
        
        // Update the follows graphs
        if (!mentionedUsers.isEmpty()) {
            followsGraph.put(author, mentionedUsers);
        }
    }
    
    return followsGraph;
}

public static List<String> influencers(Map<String, Set<String>> followsGraph) {
    // Step 1: Count mentions
    Map<String, Integer> mentionCounts = new HashMap<>();
    
    for (Set<String> followers : followsGraph.values()) {
        for (String follower : followers) {
            mentionCounts.put(follower, mentionCounts.getOrDefault(follower, 0) + 1);
        }
    }

    // Step 2: Sort influencers by count in descending order, and by name in case of ties
    List<String> influencers = new ArrayList<>(mentionCounts.keySet());
    influencers.sort((user1, user2) -> {
        int countComparison = Integer.compare(mentionCounts.get(user2), mentionCounts.get(user1));
        if (countComparison == 0) {
            return user1.compareTo(user2); // Alphabetical order if influence is tied
        }
        return countComparison;
    });

    return influencers;
}
}